﻿namespace MobileShopMangementSystem
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges9 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges10 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges11 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges12 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges13 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges14 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges15 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges16 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges17 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges18 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges19 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges20 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            panel1 = new Panel();
            btnCancel = new Guna.UI2.WinForms.Guna2Button();
            guna2Button2 = new Guna.UI2.WinForms.Guna2Button();
            txtPassword = new Guna.UI2.WinForms.Guna2TextBox();
            btnMinimize = new Guna.UI2.WinForms.Guna2Button();
            btnDeletePhone = new Guna.UI2.WinForms.Guna2Button();
            btnCustomerRecords = new Guna.UI2.WinForms.Guna2Button();
            btnStock = new Guna.UI2.WinForms.Guna2Button();
            btnCustomers = new Guna.UI2.WinForms.Guna2Button();
            guna2Button1 = new Guna.UI2.WinForms.Guna2Button();
            btnExit = new Guna.UI2.WinForms.Guna2Button();
            panel2 = new Panel();
            uC_Login1 = new AllUserControl.UC_Login();
            uC_DeletePhoneRecord1 = new AllUserControl.UC_DeletePhoneRecord();
            uC_CustomerRecords1 = new AllUserControl.UC_CustomerRecords();
            uC_Stock1 = new AllUserControl.UC_Stock();
            uC_Customer1 = new AllUserControl.UC_Customer();
            uC_AddNewPhone1 = new AllUserControl.UC_AddNewPhone();
            guna2Elipse1 = new Guna.UI2.WinForms.Guna2Elipse(components);
            guna2Elipse2 = new Guna.UI2.WinForms.Guna2Elipse(components);
            guna2Elipse3 = new Guna.UI2.WinForms.Guna2Elipse(components);
            guna2Elipse4 = new Guna.UI2.WinForms.Guna2Elipse(components);
            guna2Elipse5 = new Guna.UI2.WinForms.Guna2Elipse(components);
            guna2Elipse6 = new Guna.UI2.WinForms.Guna2Elipse(components);
            guna2Elipse7 = new Guna.UI2.WinForms.Guna2Elipse(components);
            guna2Elipse8 = new Guna.UI2.WinForms.Guna2Elipse(components);
            guna2Elipse9 = new Guna.UI2.WinForms.Guna2Elipse(components);
            guna2Elipse10 = new Guna.UI2.WinForms.Guna2Elipse(components);
            guna2Elipse11 = new Guna.UI2.WinForms.Guna2Elipse(components);
            guna2Elipse12 = new Guna.UI2.WinForms.Guna2Elipse(components);
            guna2Elipse13 = new Guna.UI2.WinForms.Guna2Elipse(components);
            guna2Elipse14 = new Guna.UI2.WinForms.Guna2Elipse(components);
            guna2Elipse15 = new Guna.UI2.WinForms.Guna2Elipse(components);
            guna2Elipse16 = new Guna.UI2.WinForms.Guna2Elipse(components);
            guna2Elipse17 = new Guna.UI2.WinForms.Guna2Elipse(components);
            guna2Elipse18 = new Guna.UI2.WinForms.Guna2Elipse(components);
            guna2Elipse19 = new Guna.UI2.WinForms.Guna2Elipse(components);
            guna2Elipse20 = new Guna.UI2.WinForms.Guna2Elipse(components);
            guna2Elipse21 = new Guna.UI2.WinForms.Guna2Elipse(components);
            guna2Elipse22 = new Guna.UI2.WinForms.Guna2Elipse(components);
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left;
            panel1.BackColor = Color.FromArgb(0, 118, 221);
            panel1.Controls.Add(btnCancel);
            panel1.Controls.Add(guna2Button2);
            panel1.Controls.Add(txtPassword);
            panel1.Controls.Add(btnMinimize);
            panel1.Controls.Add(btnDeletePhone);
            panel1.Controls.Add(btnCustomerRecords);
            panel1.Controls.Add(btnStock);
            panel1.Controls.Add(btnCustomers);
            panel1.Controls.Add(guna2Button1);
            panel1.Controls.Add(btnExit);
            panel1.Location = new Point(3, 5);
            panel1.Name = "panel1";
            panel1.Size = new Size(218, 758);
            panel1.TabIndex = 0;
            // 
            // btnCancel
            // 
            btnCancel.CustomizableEdges = customizableEdges1;
            btnCancel.DisabledState.BorderColor = Color.DarkGray;
            btnCancel.DisabledState.CustomBorderColor = Color.DarkGray;
            btnCancel.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnCancel.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnCancel.FillColor = Color.FromArgb(0, 118, 221);
            btnCancel.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold);
            btnCancel.ForeColor = Color.White;
            btnCancel.Location = new Point(122, 411);
            btnCancel.Name = "btnCancel";
            btnCancel.ShadowDecoration.CustomizableEdges = customizableEdges2;
            btnCancel.Size = new Size(87, 39);
            btnCancel.TabIndex = 9;
            btnCancel.Text = "Cancel";
            btnCancel.Click += btnCancel_Click;
            // 
            // guna2Button2
            // 
            guna2Button2.CustomizableEdges = customizableEdges3;
            guna2Button2.DisabledState.BorderColor = Color.DarkGray;
            guna2Button2.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2Button2.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2Button2.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2Button2.FillColor = Color.FromArgb(0, 118, 221);
            guna2Button2.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold);
            guna2Button2.ForeColor = Color.White;
            guna2Button2.Location = new Point(3, 411);
            guna2Button2.Name = "guna2Button2";
            guna2Button2.ShadowDecoration.CustomizableEdges = customizableEdges4;
            guna2Button2.Size = new Size(87, 39);
            guna2Button2.TabIndex = 8;
            guna2Button2.Text = "Verify";
            guna2Button2.Click += guna2Button2_Click;
            // 
            // txtPassword
            // 
            txtPassword.CustomizableEdges = customizableEdges5;
            txtPassword.DefaultText = "";
            txtPassword.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtPassword.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtPassword.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtPassword.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtPassword.FillColor = Color.FromArgb(0, 118, 221);
            txtPassword.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtPassword.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtPassword.ForeColor = Color.White;
            txtPassword.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtPassword.Location = new Point(12, 354);
            txtPassword.Margin = new Padding(4);
            txtPassword.Name = "txtPassword";
            txtPassword.PasswordChar = '*';
            txtPassword.PlaceholderText = "";
            txtPassword.SelectedText = "";
            txtPassword.ShadowDecoration.CustomizableEdges = customizableEdges6;
            txtPassword.Size = new Size(197, 41);
            txtPassword.TabIndex = 7;
            txtPassword.TextAlign = HorizontalAlignment.Center;
            // 
            // btnMinimize
            // 
            btnMinimize.CustomizableEdges = customizableEdges7;
            btnMinimize.DisabledState.BorderColor = Color.DarkGray;
            btnMinimize.DisabledState.CustomBorderColor = Color.DarkGray;
            btnMinimize.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnMinimize.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnMinimize.FillColor = Color.FromArgb(0, 118, 221);
            btnMinimize.Font = new Font("Segoe UI", 9F);
            btnMinimize.ForeColor = Color.White;
            btnMinimize.Image = (Image)resources.GetObject("btnMinimize.Image");
            btnMinimize.Location = new Point(37, 3);
            btnMinimize.Name = "btnMinimize";
            btnMinimize.ShadowDecoration.CustomizableEdges = customizableEdges8;
            btnMinimize.Size = new Size(28, 25);
            btnMinimize.TabIndex = 6;
            btnMinimize.Click += btnMinimize_Click;
            // 
            // btnDeletePhone
            // 
            btnDeletePhone.BorderRadius = 26;
            btnDeletePhone.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
            btnDeletePhone.CheckedState.FillColor = Color.White;
            btnDeletePhone.CheckedState.ForeColor = Color.FromArgb(0, 118, 221);
            btnDeletePhone.CustomizableEdges = customizableEdges9;
            btnDeletePhone.DisabledState.BorderColor = Color.DarkGray;
            btnDeletePhone.DisabledState.CustomBorderColor = Color.DarkGray;
            btnDeletePhone.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnDeletePhone.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnDeletePhone.FillColor = Color.FromArgb(0, 118, 221);
            btnDeletePhone.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnDeletePhone.ForeColor = Color.White;
            btnDeletePhone.Image = (Image)resources.GetObject("btnDeletePhone.Image");
            btnDeletePhone.ImageAlign = HorizontalAlignment.Left;
            btnDeletePhone.ImageSize = new Size(30, 30);
            btnDeletePhone.Location = new Point(0, 302);
            btnDeletePhone.Name = "btnDeletePhone";
            btnDeletePhone.ShadowDecoration.CustomizableEdges = customizableEdges10;
            btnDeletePhone.Size = new Size(215, 45);
            btnDeletePhone.TabIndex = 5;
            btnDeletePhone.Text = "Delete Phone Record";
            btnDeletePhone.Click += btnDeletePhone_Click;
            // 
            // btnCustomerRecords
            // 
            btnCustomerRecords.BorderRadius = 26;
            btnCustomerRecords.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
            btnCustomerRecords.CheckedState.FillColor = Color.White;
            btnCustomerRecords.CheckedState.ForeColor = Color.FromArgb(0, 118, 221);
            btnCustomerRecords.CustomizableEdges = customizableEdges11;
            btnCustomerRecords.DisabledState.BorderColor = Color.DarkGray;
            btnCustomerRecords.DisabledState.CustomBorderColor = Color.DarkGray;
            btnCustomerRecords.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnCustomerRecords.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnCustomerRecords.FillColor = Color.FromArgb(0, 118, 221);
            btnCustomerRecords.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnCustomerRecords.ForeColor = Color.White;
            btnCustomerRecords.Image = (Image)resources.GetObject("btnCustomerRecords.Image");
            btnCustomerRecords.ImageAlign = HorizontalAlignment.Left;
            btnCustomerRecords.ImageSize = new Size(30, 30);
            btnCustomerRecords.Location = new Point(3, 240);
            btnCustomerRecords.Name = "btnCustomerRecords";
            btnCustomerRecords.ShadowDecoration.CustomizableEdges = customizableEdges12;
            btnCustomerRecords.Size = new Size(215, 45);
            btnCustomerRecords.TabIndex = 4;
            btnCustomerRecords.Text = "Customer Records";
            btnCustomerRecords.Click += btnCustomerRecords_Click;
            // 
            // btnStock
            // 
            btnStock.BorderRadius = 26;
            btnStock.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
            btnStock.CheckedState.FillColor = Color.White;
            btnStock.CheckedState.ForeColor = Color.FromArgb(0, 118, 221);
            btnStock.CustomizableEdges = customizableEdges13;
            btnStock.DisabledState.BorderColor = Color.DarkGray;
            btnStock.DisabledState.CustomBorderColor = Color.DarkGray;
            btnStock.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnStock.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnStock.FillColor = Color.FromArgb(0, 118, 221);
            btnStock.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnStock.ForeColor = Color.White;
            btnStock.Image = (Image)resources.GetObject("btnStock.Image");
            btnStock.ImageAlign = HorizontalAlignment.Left;
            btnStock.ImageSize = new Size(30, 30);
            btnStock.Location = new Point(3, 179);
            btnStock.Name = "btnStock";
            btnStock.ShadowDecoration.CustomizableEdges = customizableEdges14;
            btnStock.Size = new Size(215, 45);
            btnStock.TabIndex = 3;
            btnStock.Text = "Stock";
            btnStock.Click += btnStock_Click;
            // 
            // btnCustomers
            // 
            btnCustomers.BorderRadius = 26;
            btnCustomers.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
            btnCustomers.CheckedState.FillColor = Color.White;
            btnCustomers.CheckedState.ForeColor = Color.FromArgb(0, 118, 221);
            btnCustomers.CustomizableEdges = customizableEdges15;
            btnCustomers.DisabledState.BorderColor = Color.DarkGray;
            btnCustomers.DisabledState.CustomBorderColor = Color.DarkGray;
            btnCustomers.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnCustomers.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnCustomers.FillColor = Color.FromArgb(0, 118, 221);
            btnCustomers.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnCustomers.ForeColor = Color.White;
            btnCustomers.Image = (Image)resources.GetObject("btnCustomers.Image");
            btnCustomers.ImageAlign = HorizontalAlignment.Left;
            btnCustomers.ImageSize = new Size(30, 30);
            btnCustomers.Location = new Point(0, 117);
            btnCustomers.Name = "btnCustomers";
            btnCustomers.ShadowDecoration.CustomizableEdges = customizableEdges16;
            btnCustomers.Size = new Size(215, 45);
            btnCustomers.TabIndex = 2;
            btnCustomers.Text = "Customers";
            btnCustomers.Click += btnCustomers_Click;
            // 
            // guna2Button1
            // 
            guna2Button1.BorderRadius = 26;
            guna2Button1.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
            guna2Button1.CheckedState.FillColor = Color.White;
            guna2Button1.CheckedState.ForeColor = Color.FromArgb(0, 118, 221);
            guna2Button1.CustomizableEdges = customizableEdges17;
            guna2Button1.DisabledState.BorderColor = Color.DarkGray;
            guna2Button1.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2Button1.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2Button1.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2Button1.FillColor = Color.FromArgb(0, 118, 221);
            guna2Button1.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            guna2Button1.ForeColor = Color.White;
            guna2Button1.Image = (Image)resources.GetObject("guna2Button1.Image");
            guna2Button1.ImageAlign = HorizontalAlignment.Left;
            guna2Button1.ImageSize = new Size(30, 30);
            guna2Button1.Location = new Point(0, 57);
            guna2Button1.Name = "guna2Button1";
            guna2Button1.ShadowDecoration.CustomizableEdges = customizableEdges18;
            guna2Button1.Size = new Size(215, 45);
            guna2Button1.TabIndex = 1;
            guna2Button1.Text = "Add New Phone";
            guna2Button1.Click += guna2Button1_Click;
            // 
            // btnExit
            // 
            btnExit.CustomizableEdges = customizableEdges19;
            btnExit.DisabledState.BorderColor = Color.DarkGray;
            btnExit.DisabledState.CustomBorderColor = Color.DarkGray;
            btnExit.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnExit.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnExit.FillColor = Color.FromArgb(0, 118, 221);
            btnExit.Font = new Font("Segoe UI", 9F);
            btnExit.ForeColor = Color.White;
            btnExit.Image = (Image)resources.GetObject("btnExit.Image");
            btnExit.Location = new Point(3, 3);
            btnExit.Name = "btnExit";
            btnExit.ShadowDecoration.CustomizableEdges = customizableEdges20;
            btnExit.Size = new Size(28, 25);
            btnExit.TabIndex = 0;
            btnExit.Click += btnExit_Click;
            // 
            // panel2
            // 
            panel2.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            panel2.BackColor = Color.FromArgb(0, 118, 221);
            panel2.Controls.Add(uC_Login1);
            panel2.Controls.Add(uC_DeletePhoneRecord1);
            panel2.Controls.Add(uC_CustomerRecords1);
            panel2.Controls.Add(uC_Stock1);
            panel2.Controls.Add(uC_Customer1);
            panel2.Controls.Add(uC_AddNewPhone1);
            panel2.Location = new Point(227, 5);
            panel2.Name = "panel2";
            panel2.Size = new Size(976, 758);
            panel2.TabIndex = 1;
            // 
            // uC_Login1
            // 
            uC_Login1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            uC_Login1.BackColor = Color.FromArgb(0, 118, 221);
            uC_Login1.Location = new Point(0, 0);
            uC_Login1.Name = "uC_Login1";
            uC_Login1.Size = new Size(1148, 755);
            uC_Login1.TabIndex = 5;
            uC_Login1.VisibleChanged += uC_Login1_VisibleChanged;
            // 
            // uC_DeletePhoneRecord1
            // 
            uC_DeletePhoneRecord1.AutoSize = true;
            uC_DeletePhoneRecord1.BackColor = Color.White;
            uC_DeletePhoneRecord1.Location = new Point(3, 3);
            uC_DeletePhoneRecord1.Name = "uC_DeletePhoneRecord1";
            uC_DeletePhoneRecord1.Size = new Size(1487, 852);
            uC_DeletePhoneRecord1.TabIndex = 4;
            // 
            // uC_CustomerRecords1
            // 
            uC_CustomerRecords1.AutoSize = true;
            uC_CustomerRecords1.BackColor = Color.White;
            uC_CustomerRecords1.Location = new Point(3, 7);
            uC_CustomerRecords1.Name = "uC_CustomerRecords1";
            uC_CustomerRecords1.Size = new Size(1325, 756);
            uC_CustomerRecords1.TabIndex = 3;
            // 
            // uC_Stock1
            // 
            uC_Stock1.AutoSize = true;
            uC_Stock1.BackColor = Color.White;
            uC_Stock1.Font = new Font("Segoe UI", 11.25F);
            uC_Stock1.ForeColor = Color.Black;
            uC_Stock1.Location = new Point(3, 8);
            uC_Stock1.Margin = new Padding(3, 4, 3, 4);
            uC_Stock1.Name = "uC_Stock1";
            uC_Stock1.Size = new Size(1315, 1068);
            uC_Stock1.TabIndex = 2;
            // 
            // uC_Customer1
            // 
            uC_Customer1.BackColor = Color.White;
            uC_Customer1.Font = new Font("Century Gothic", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            uC_Customer1.Location = new Point(3, 3);
            uC_Customer1.Name = "uC_Customer1";
            uC_Customer1.Size = new Size(1264, 887);
            uC_Customer1.TabIndex = 1;
            // 
            // uC_AddNewPhone1
            // 
            uC_AddNewPhone1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            uC_AddNewPhone1.BackColor = Color.White;
            uC_AddNewPhone1.ForeColor = Color.Black;
            uC_AddNewPhone1.Location = new Point(-2, 0);
            uC_AddNewPhone1.Name = "uC_AddNewPhone1";
            uC_AddNewPhone1.Size = new Size(969, 752);
            uC_AddNewPhone1.TabIndex = 0;
            // 
            // guna2Elipse1
            // 
            guna2Elipse1.BorderRadius = 30;
            guna2Elipse1.TargetControl = this;
            // 
            // guna2Elipse2
            // 
            guna2Elipse2.BorderRadius = 30;
            guna2Elipse2.TargetControl = this;
            // 
            // guna2Elipse3
            // 
            guna2Elipse3.BorderRadius = 26;
            // 
            // guna2Elipse4
            // 
            guna2Elipse4.BorderRadius = 26;
            // 
            // guna2Elipse5
            // 
            guna2Elipse5.BorderRadius = 26;
            // 
            // guna2Elipse6
            // 
            guna2Elipse6.BorderRadius = 26;
            // 
            // guna2Elipse7
            // 
            guna2Elipse7.BorderRadius = 26;
            // 
            // guna2Elipse8
            // 
            guna2Elipse8.BorderRadius = 26;
            // 
            // guna2Elipse9
            // 
            guna2Elipse9.BorderRadius = 26;
            // 
            // guna2Elipse10
            // 
            guna2Elipse10.BorderRadius = 26;
            // 
            // guna2Elipse11
            // 
            guna2Elipse11.BorderRadius = 26;
            // 
            // guna2Elipse12
            // 
            guna2Elipse12.BorderRadius = 26;
            // 
            // guna2Elipse13
            // 
            guna2Elipse13.BorderRadius = 26;
            // 
            // guna2Elipse14
            // 
            guna2Elipse14.BorderRadius = 26;
            // 
            // guna2Elipse15
            // 
            guna2Elipse15.BorderRadius = 26;
            // 
            // guna2Elipse16
            // 
            guna2Elipse16.BorderRadius = 26;
            // 
            // guna2Elipse17
            // 
            guna2Elipse17.BorderRadius = 26;
            // 
            // guna2Elipse18
            // 
            guna2Elipse18.BorderRadius = 26;
            // 
            // guna2Elipse19
            // 
            guna2Elipse19.BorderRadius = 30;
            guna2Elipse19.TargetControl = panel2;
            // 
            // guna2Elipse20
            // 
            guna2Elipse20.BorderRadius = 30;
            guna2Elipse20.TargetControl = this;
            // 
            // guna2Elipse21
            // 
            guna2Elipse21.BorderRadius = 30;
            guna2Elipse21.TargetControl = panel2;
            // 
            // guna2Elipse22
            // 
            guna2Elipse22.BorderRadius = 26;
            guna2Elipse22.TargetControl = panel2;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 17F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(0, 118, 221);
            ClientSize = new Size(1206, 821);
            Controls.Add(panel2);
            Controls.Add(panel1);
            Font = new Font("Century Gothic", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Form1";
            WindowState = FormWindowState.Maximized;
            Load += Form1_Load;
            panel1.ResumeLayout(false);
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private Panel panel2;
        private Guna.UI2.WinForms.Guna2Button btnExit;
        private Guna.UI2.WinForms.Guna2Button guna2Button1;
        private Guna.UI2.WinForms.Guna2Button btnDeletePhone;
        private Guna.UI2.WinForms.Guna2Button btnCustomerRecords;
        private Guna.UI2.WinForms.Guna2Button btnStock;
        private Guna.UI2.WinForms.Guna2Button btnCustomers;
        private Guna.UI2.WinForms.Guna2Button btnMinimize;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse1;
        private AllUserControl.UC_AddNewPhone uC_AddNewPhone1;
        private AllUserControl.UC_Customer uC_Customer1;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse2;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse3;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse4;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse5;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse6;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse7;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse8;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse9;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse10;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse11;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse12;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse13;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse14;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse15;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse16;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse17;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse18;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse19;
        private AllUserControl.UC_Stock uC_Stock1;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse20;
        private AllUserControl.UC_CustomerRecords uC_CustomerRecords1;
        private Guna.UI2.WinForms.Guna2Button btnCancel;
        private Guna.UI2.WinForms.Guna2Button guna2Button2;
        private Guna.UI2.WinForms.Guna2TextBox txtPassword;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse21;
        private AllUserControl.UC_DeletePhoneRecord uC_DeletePhoneRecord1;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse22;
        private AllUserControl.UC_Login uC_Login1;
    }
}
