﻿namespace MobileShopMangementSystem.AllUserControl
{
    partial class UC_AddNewPhone
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UC_AddNewPhone));
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges9 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges10 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges11 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges12 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges13 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges14 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges15 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges16 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges17 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges18 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges19 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges20 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges21 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges22 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges23 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges24 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges25 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges26 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges27 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges28 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            label1 = new Label();
            label2 = new Label();
            txtCompany = new Guna.UI2.WinForms.Guna2TextBox();
            txtModel = new Guna.UI2.WinForms.Guna2TextBox();
            label3 = new Label();
            label4 = new Label();
            txtRam = new Guna.UI2.WinForms.Guna2ComboBox();
            txtInternal = new Guna.UI2.WinForms.Guna2ComboBox();
            label5 = new Label();
            txtExpandable = new Guna.UI2.WinForms.Guna2ComboBox();
            label6 = new Label();
            txtDisplay = new Guna.UI2.WinForms.Guna2ComboBox();
            label7 = new Label();
            txtRear = new Guna.UI2.WinForms.Guna2ComboBox();
            label8 = new Label();
            txtFront = new Guna.UI2.WinForms.Guna2ComboBox();
            label9 = new Label();
            txtFingerprint = new Guna.UI2.WinForms.Guna2ComboBox();
            label10 = new Label();
            txtSim = new Guna.UI2.WinForms.Guna2ComboBox();
            label11 = new Label();
            txtNetwork = new Guna.UI2.WinForms.Guna2ComboBox();
            label12 = new Label();
            label13 = new Label();
            txtPrice = new Guna.UI2.WinForms.Guna2TextBox();
            btnSave = new Guna.UI2.WinForms.Guna2Button();
            btnReset = new Guna.UI2.WinForms.Guna2Button();
            guna2Elipse1 = new Guna.UI2.WinForms.Guna2Elipse(components);
            SuspendLayout();
            // 
            // label1
            // 
            label1.Font = new Font("Century Gothic", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Image = (Image)resources.GetObject("label1.Image");
            label1.ImageAlign = ContentAlignment.MiddleLeft;
            label1.Location = new Point(3, 24);
            label1.Name = "label1";
            label1.Size = new Size(321, 45);
            label1.TabIndex = 0;
            label1.Text = "New Phone Record";
            label1.TextAlign = ContentAlignment.MiddleRight;
            label1.Click += label1_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Microsoft Sans Serif", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.Location = new Point(69, 97);
            label2.Name = "label2";
            label2.Size = new Size(72, 18);
            label2.TabIndex = 1;
            label2.Text = "Company";
            // 
            // txtCompany
            // 
            txtCompany.CustomizableEdges = customizableEdges1;
            txtCompany.DefaultText = "";
            txtCompany.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtCompany.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtCompany.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtCompany.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtCompany.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtCompany.Font = new Font("Microsoft Sans Serif", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtCompany.ForeColor = Color.Black;
            txtCompany.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtCompany.Location = new Point(68, 125);
            txtCompany.Margin = new Padding(5, 4, 5, 4);
            txtCompany.Name = "txtCompany";
            txtCompany.PasswordChar = '\0';
            txtCompany.PlaceholderText = "";
            txtCompany.SelectedText = "";
            txtCompany.ShadowDecoration.CustomizableEdges = customizableEdges2;
            txtCompany.Size = new Size(419, 46);
            txtCompany.Style = Guna.UI2.WinForms.Enums.TextBoxStyle.Material;
            txtCompany.TabIndex = 2;
            // 
            // txtModel
            // 
            txtModel.CustomizableEdges = customizableEdges3;
            txtModel.DefaultText = "";
            txtModel.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtModel.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtModel.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtModel.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtModel.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtModel.Font = new Font("Microsoft Sans Serif", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtModel.ForeColor = Color.Black;
            txtModel.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtModel.Location = new Point(71, 206);
            txtModel.Margin = new Padding(5, 4, 5, 4);
            txtModel.Name = "txtModel";
            txtModel.PasswordChar = '\0';
            txtModel.PlaceholderText = "";
            txtModel.SelectedText = "";
            txtModel.ShadowDecoration.CustomizableEdges = customizableEdges4;
            txtModel.Size = new Size(416, 46);
            txtModel.Style = Guna.UI2.WinForms.Enums.TextBoxStyle.Material;
            txtModel.TabIndex = 4;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Microsoft Sans Serif", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.Location = new Point(69, 184);
            label3.Name = "label3";
            label3.Size = new Size(93, 18);
            label3.TabIndex = 3;
            label3.Text = "Model Name";
            label3.Click += label3_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Microsoft Sans Serif", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label4.Location = new Point(69, 270);
            label4.Name = "label4";
            label4.Size = new Size(40, 18);
            label4.TabIndex = 5;
            label4.Text = "Ram";
            // 
            // txtRam
            // 
            txtRam.BackColor = Color.Transparent;
            txtRam.CustomizableEdges = customizableEdges5;
            txtRam.DrawMode = DrawMode.OwnerDrawFixed;
            txtRam.DropDownStyle = ComboBoxStyle.DropDownList;
            txtRam.FocusedColor = Color.FromArgb(94, 148, 255);
            txtRam.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtRam.Font = new Font("Segoe UI", 10F);
            txtRam.ForeColor = Color.Black;
            txtRam.ItemHeight = 30;
            txtRam.Items.AddRange(new object[] { "1 GB", "2 GB", "3 GB", "4 GB", "6 GB", "8 GB ", "16 GB" });
            txtRam.Location = new Point(71, 302);
            txtRam.Name = "txtRam";
            txtRam.ShadowDecoration.CustomizableEdges = customizableEdges6;
            txtRam.Size = new Size(416, 36);
            txtRam.Style = Guna.UI2.WinForms.Enums.TextBoxStyle.Material;
            txtRam.TabIndex = 6;
            // 
            // txtInternal
            // 
            txtInternal.BackColor = Color.Transparent;
            txtInternal.CustomizableEdges = customizableEdges7;
            txtInternal.DrawMode = DrawMode.OwnerDrawFixed;
            txtInternal.DropDownStyle = ComboBoxStyle.DropDownList;
            txtInternal.FocusedColor = Color.FromArgb(94, 148, 255);
            txtInternal.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtInternal.Font = new Font("Segoe UI", 10F);
            txtInternal.ForeColor = Color.Black;
            txtInternal.ItemHeight = 30;
            txtInternal.Items.AddRange(new object[] { "4 GB", "8 GB", "16 GB", "32 GB", "64 GB ", "128 GB" });
            txtInternal.Location = new Point(71, 385);
            txtInternal.Name = "txtInternal";
            txtInternal.ShadowDecoration.CustomizableEdges = customizableEdges8;
            txtInternal.Size = new Size(416, 36);
            txtInternal.Style = Guna.UI2.WinForms.Enums.TextBoxStyle.Material;
            txtInternal.TabIndex = 8;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Microsoft Sans Serif", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label5.Location = new Point(69, 353);
            label5.Name = "label5";
            label5.Size = new Size(111, 18);
            label5.TabIndex = 7;
            label5.Text = "Internal Storage";
            // 
            // txtExpandable
            // 
            txtExpandable.BackColor = Color.Transparent;
            txtExpandable.CustomizableEdges = customizableEdges9;
            txtExpandable.DrawMode = DrawMode.OwnerDrawFixed;
            txtExpandable.DropDownStyle = ComboBoxStyle.DropDownList;
            txtExpandable.FocusedColor = Color.FromArgb(94, 148, 255);
            txtExpandable.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtExpandable.Font = new Font("Segoe UI", 10F);
            txtExpandable.ForeColor = Color.Black;
            txtExpandable.ItemHeight = 30;
            txtExpandable.Items.AddRange(new object[] { "16 GB", "32 GB", "64 GB", "128 GB", "256 GB" });
            txtExpandable.Location = new Point(71, 478);
            txtExpandable.Name = "txtExpandable";
            txtExpandable.ShadowDecoration.CustomizableEdges = customizableEdges10;
            txtExpandable.Size = new Size(416, 36);
            txtExpandable.Style = Guna.UI2.WinForms.Enums.TextBoxStyle.Material;
            txtExpandable.TabIndex = 10;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Microsoft Sans Serif", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label6.Location = new Point(69, 446);
            label6.Name = "label6";
            label6.Size = new Size(140, 18);
            label6.TabIndex = 9;
            label6.Text = "Expandable Storage";
            // 
            // txtDisplay
            // 
            txtDisplay.BackColor = Color.Transparent;
            txtDisplay.CustomizableEdges = customizableEdges11;
            txtDisplay.DrawMode = DrawMode.OwnerDrawFixed;
            txtDisplay.DropDownStyle = ComboBoxStyle.DropDownList;
            txtDisplay.FocusedColor = Color.FromArgb(94, 148, 255);
            txtDisplay.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtDisplay.Font = new Font("Segoe UI", 10F);
            txtDisplay.ForeColor = Color.Black;
            txtDisplay.ItemHeight = 30;
            txtDisplay.Items.AddRange(new object[] { "5.0 inch", "5.5 inch", "6.0 inch", "6.1 inch", "6.3 inch", "6.5 inch" });
            txtDisplay.Location = new Point(71, 559);
            txtDisplay.Name = "txtDisplay";
            txtDisplay.ShadowDecoration.CustomizableEdges = customizableEdges12;
            txtDisplay.Size = new Size(416, 36);
            txtDisplay.Style = Guna.UI2.WinForms.Enums.TextBoxStyle.Material;
            txtDisplay.TabIndex = 12;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Microsoft Sans Serif", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label7.Location = new Point(69, 527);
            label7.Name = "label7";
            label7.Size = new Size(56, 18);
            label7.TabIndex = 11;
            label7.Text = "Display";
            // 
            // txtRear
            // 
            txtRear.BackColor = Color.Transparent;
            txtRear.CustomizableEdges = customizableEdges13;
            txtRear.DrawMode = DrawMode.OwnerDrawFixed;
            txtRear.DropDownStyle = ComboBoxStyle.DropDownList;
            txtRear.FocusedColor = Color.FromArgb(94, 148, 255);
            txtRear.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtRear.Font = new Font("Segoe UI", 10F);
            txtRear.ForeColor = Color.Black;
            txtRear.ItemHeight = 30;
            txtRear.Items.AddRange(new object[] { "5 MP", "8 MP", "10 MP", "11 MP", "12 MP", "13 MP ", "15 MP", "20 MP", "48 MP", "108MP" });
            txtRear.Location = new Point(619, 123);
            txtRear.Name = "txtRear";
            txtRear.ShadowDecoration.CustomizableEdges = customizableEdges14;
            txtRear.Size = new Size(416, 36);
            txtRear.Style = Guna.UI2.WinForms.Enums.TextBoxStyle.Material;
            txtRear.TabIndex = 14;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Microsoft Sans Serif", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label8.Location = new Point(617, 91);
            label8.Name = "label8";
            label8.Size = new Size(97, 18);
            label8.TabIndex = 13;
            label8.Text = "Rear Camera";
            // 
            // txtFront
            // 
            txtFront.BackColor = Color.Transparent;
            txtFront.CustomizableEdges = customizableEdges15;
            txtFront.DrawMode = DrawMode.OwnerDrawFixed;
            txtFront.DropDownStyle = ComboBoxStyle.DropDownList;
            txtFront.FocusedColor = Color.FromArgb(94, 148, 255);
            txtFront.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtFront.Font = new Font("Segoe UI", 10F);
            txtFront.ForeColor = Color.Black;
            txtFront.ItemHeight = 30;
            txtFront.Items.AddRange(new object[] { "2 MP", "3 MP", "5 MP", "8 MP ", "10 MP", "20 MP", "24 MP", "30 MP" });
            txtFront.Location = new Point(619, 225);
            txtFront.Name = "txtFront";
            txtFront.ShadowDecoration.CustomizableEdges = customizableEdges16;
            txtFront.Size = new Size(416, 36);
            txtFront.Style = Guna.UI2.WinForms.Enums.TextBoxStyle.Material;
            txtFront.TabIndex = 16;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Microsoft Sans Serif", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label9.Location = new Point(617, 193);
            label9.Name = "label9";
            label9.Size = new Size(100, 18);
            label9.TabIndex = 15;
            label9.Text = "Front Camera";
            // 
            // txtFingerprint
            // 
            txtFingerprint.BackColor = Color.Transparent;
            txtFingerprint.CustomizableEdges = customizableEdges17;
            txtFingerprint.DrawMode = DrawMode.OwnerDrawFixed;
            txtFingerprint.DropDownStyle = ComboBoxStyle.DropDownList;
            txtFingerprint.FocusedColor = Color.FromArgb(94, 148, 255);
            txtFingerprint.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtFingerprint.Font = new Font("Segoe UI", 10F);
            txtFingerprint.ForeColor = Color.Black;
            txtFingerprint.ItemHeight = 30;
            txtFingerprint.Items.AddRange(new object[] { "Yes ", "No" });
            txtFingerprint.Location = new Point(613, 314);
            txtFingerprint.Name = "txtFingerprint";
            txtFingerprint.ShadowDecoration.CustomizableEdges = customizableEdges18;
            txtFingerprint.Size = new Size(416, 36);
            txtFingerprint.Style = Guna.UI2.WinForms.Enums.TextBoxStyle.Material;
            txtFingerprint.TabIndex = 18;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Microsoft Sans Serif", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label10.Location = new Point(611, 282);
            label10.Name = "label10";
            label10.Size = new Size(129, 18);
            label10.TabIndex = 17;
            label10.Text = "Fingerprint Sensor";
            // 
            // txtSim
            // 
            txtSim.BackColor = Color.Transparent;
            txtSim.CustomizableEdges = customizableEdges19;
            txtSim.DrawMode = DrawMode.OwnerDrawFixed;
            txtSim.DropDownStyle = ComboBoxStyle.DropDownList;
            txtSim.FocusedColor = Color.FromArgb(94, 148, 255);
            txtSim.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtSim.Font = new Font("Segoe UI", 10F);
            txtSim.ForeColor = Color.Black;
            txtSim.ItemHeight = 30;
            txtSim.Items.AddRange(new object[] { "One Sim", "Dual Sim ", "Singal Sim with eSim" });
            txtSim.Location = new Point(619, 397);
            txtSim.Name = "txtSim";
            txtSim.ShadowDecoration.CustomizableEdges = customizableEdges20;
            txtSim.Size = new Size(416, 36);
            txtSim.Style = Guna.UI2.WinForms.Enums.TextBoxStyle.Material;
            txtSim.TabIndex = 20;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Microsoft Sans Serif", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label11.Location = new Point(617, 365);
            label11.Name = "label11";
            label11.Size = new Size(70, 18);
            label11.TabIndex = 19;
            label11.Text = "Sim Type";
            // 
            // txtNetwork
            // 
            txtNetwork.BackColor = Color.Transparent;
            txtNetwork.CustomizableEdges = customizableEdges21;
            txtNetwork.DrawMode = DrawMode.OwnerDrawFixed;
            txtNetwork.DropDownStyle = ComboBoxStyle.DropDownList;
            txtNetwork.FocusedColor = Color.FromArgb(94, 148, 255);
            txtNetwork.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtNetwork.Font = new Font("Segoe UI", 10F);
            txtNetwork.ForeColor = Color.Black;
            txtNetwork.ItemHeight = 30;
            txtNetwork.Items.AddRange(new object[] { "2G", "2G,3G", "2G,3G & 4G VOLT ", "2G,3G, 4G VOLT, 5G" });
            txtNetwork.Location = new Point(613, 490);
            txtNetwork.Name = "txtNetwork";
            txtNetwork.ShadowDecoration.CustomizableEdges = customizableEdges22;
            txtNetwork.Size = new Size(416, 36);
            txtNetwork.Style = Guna.UI2.WinForms.Enums.TextBoxStyle.Material;
            txtNetwork.TabIndex = 22;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Microsoft Sans Serif", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label12.Location = new Point(611, 458);
            label12.Name = "label12";
            label12.Size = new Size(100, 18);
            label12.TabIndex = 21;
            label12.Text = "Network Type";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Microsoft Sans Serif", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label13.Location = new Point(617, 539);
            label13.Name = "label13";
            label13.Size = new Size(42, 18);
            label13.TabIndex = 23;
            label13.Text = "Price";
            // 
            // txtPrice
            // 
            txtPrice.CustomizableEdges = customizableEdges23;
            txtPrice.DefaultText = "";
            txtPrice.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtPrice.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtPrice.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtPrice.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtPrice.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtPrice.Font = new Font("Microsoft Sans Serif", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtPrice.ForeColor = Color.Black;
            txtPrice.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtPrice.Location = new Point(613, 561);
            txtPrice.Margin = new Padding(5, 4, 5, 4);
            txtPrice.Name = "txtPrice";
            txtPrice.PasswordChar = '\0';
            txtPrice.PlaceholderText = "";
            txtPrice.SelectedText = "";
            txtPrice.ShadowDecoration.CustomizableEdges = customizableEdges24;
            txtPrice.Size = new Size(416, 46);
            txtPrice.Style = Guna.UI2.WinForms.Enums.TextBoxStyle.Material;
            txtPrice.TabIndex = 24;
            // 
            // btnSave
            // 
            btnSave.BorderRadius = 26;
            btnSave.BorderThickness = 1;
            btnSave.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
            btnSave.CheckedState.FillColor = Color.White;
            btnSave.CheckedState.ForeColor = Color.FromArgb(0, 118, 221);
            btnSave.CustomizableEdges = customizableEdges25;
            btnSave.DisabledState.BorderColor = Color.DarkGray;
            btnSave.DisabledState.CustomBorderColor = Color.DarkGray;
            btnSave.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnSave.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnSave.FillColor = Color.FromArgb(0, 118, 221);
            btnSave.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnSave.ForeColor = Color.White;
            btnSave.Image = (Image)resources.GetObject("btnSave.Image");
            btnSave.ImageAlign = HorizontalAlignment.Left;
            btnSave.ImageSize = new Size(30, 30);
            btnSave.Location = new Point(839, 614);
            btnSave.Name = "btnSave";
            btnSave.ShadowDecoration.CustomizableEdges = customizableEdges26;
            btnSave.Size = new Size(97, 45);
            btnSave.TabIndex = 25;
            btnSave.Text = "Save";
            btnSave.TextAlign = HorizontalAlignment.Right;
            btnSave.Click += btnSave_Click;
            // 
            // btnReset
            // 
            btnReset.BorderRadius = 26;
            btnReset.BorderThickness = 1;
            btnReset.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
            btnReset.CheckedState.FillColor = Color.White;
            btnReset.CheckedState.ForeColor = Color.FromArgb(0, 118, 221);
            btnReset.CustomizableEdges = customizableEdges27;
            btnReset.DisabledState.BorderColor = Color.DarkGray;
            btnReset.DisabledState.CustomBorderColor = Color.DarkGray;
            btnReset.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnReset.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnReset.FillColor = Color.FromArgb(0, 118, 221);
            btnReset.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnReset.ForeColor = Color.White;
            btnReset.Image = (Image)resources.GetObject("btnReset.Image");
            btnReset.ImageAlign = HorizontalAlignment.Left;
            btnReset.ImageSize = new Size(30, 30);
            btnReset.Location = new Point(942, 614);
            btnReset.Name = "btnReset";
            btnReset.ShadowDecoration.CustomizableEdges = customizableEdges28;
            btnReset.Size = new Size(97, 45);
            btnReset.TabIndex = 26;
            btnReset.Text = "Reset";
            btnReset.TextAlign = HorizontalAlignment.Right;
            btnReset.Click += btnReset_Click;
            // 
            // guna2Elipse1
            // 
            guna2Elipse1.BorderRadius = 26;
            guna2Elipse1.TargetControl = this;
            // 
            // UC_AddNewPhone
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            Controls.Add(btnReset);
            Controls.Add(btnSave);
            Controls.Add(txtPrice);
            Controls.Add(label13);
            Controls.Add(txtNetwork);
            Controls.Add(label12);
            Controls.Add(txtSim);
            Controls.Add(label11);
            Controls.Add(txtFingerprint);
            Controls.Add(label10);
            Controls.Add(txtFront);
            Controls.Add(label9);
            Controls.Add(txtRear);
            Controls.Add(label8);
            Controls.Add(txtDisplay);
            Controls.Add(label7);
            Controls.Add(txtExpandable);
            Controls.Add(label6);
            Controls.Add(txtInternal);
            Controls.Add(label5);
            Controls.Add(txtRam);
            Controls.Add(label4);
            Controls.Add(txtModel);
            Controls.Add(label3);
            Controls.Add(txtCompany);
            Controls.Add(label2);
            Controls.Add(label1);
            ForeColor = Color.Black;
            Name = "UC_AddNewPhone";
            Size = new Size(1095, 682);
            Load += UC_AddNewPhone_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Guna.UI2.WinForms.Guna2TextBox txtCompany;
        private Guna.UI2.WinForms.Guna2TextBox txtModel;
        private Label label3;
        private Label label4;
        private Guna.UI2.WinForms.Guna2ComboBox txtRam;
        private Guna.UI2.WinForms.Guna2ComboBox txtInternal;
        private Label label5;
        private Guna.UI2.WinForms.Guna2ComboBox txtExpandable;
        private Label label6;
        private Guna.UI2.WinForms.Guna2ComboBox txtDisplay;
        private Label label7;
        private Guna.UI2.WinForms.Guna2ComboBox txtRear;
        private Label label8;
        private Guna.UI2.WinForms.Guna2ComboBox txtFront;
        private Label label9;
        private Guna.UI2.WinForms.Guna2ComboBox txtFingerprint;
        private Label label10;
        private Guna.UI2.WinForms.Guna2ComboBox txtSim;
        private Label label11;
        private Guna.UI2.WinForms.Guna2ComboBox txtNetwork;
        private Label label12;
        private Label label13;
        private Guna.UI2.WinForms.Guna2TextBox txtPrice;
        private Guna.UI2.WinForms.Guna2Button btnSave;
        private Guna.UI2.WinForms.Guna2Button btnReset;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse1;
    }
}
