﻿namespace MobileShopMangementSystem.AllUserControl
{
    partial class UC_Stock
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UC_Stock));
            guna2DataGridView1 = new Guna.UI2.WinForms.Guna2DataGridView();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            label9 = new Label();
            label10 = new Label();
            label11 = new Label();
            label12 = new Label();
            label13 = new Label();
            displaylabel = new Label();
            expandablelabel = new Label();
            internallabel = new Label();
            ramlabel = new Label();
            modellabel = new Label();
            companylabel = new Label();
            pricelabel = new Label();
            networklabel = new Label();
            simlabel = new Label();
            fingerlabel = new Label();
            frontlabel = new Label();
            rearlabel = new Label();
            guna2Elipse3 = new Guna.UI2.WinForms.Guna2Elipse(components);
            ((System.ComponentModel.ISupportInitialize)guna2DataGridView1).BeginInit();
            SuspendLayout();
            // 
            // guna2DataGridView1
            // 
            dataGridViewCellStyle1.BackColor = Color.White;
            guna2DataGridView1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            guna2DataGridView1.BorderStyle = BorderStyle.Fixed3D;
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = Color.FromArgb(100, 88, 255);
            dataGridViewCellStyle2.Font = new Font("Segoe UI", 11.25F);
            dataGridViewCellStyle2.ForeColor = Color.White;
            dataGridViewCellStyle2.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.True;
            guna2DataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            guna2DataGridView1.ColumnHeadersHeight = 4;
            guna2DataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            dataGridViewCellStyle3.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = Color.White;
            dataGridViewCellStyle3.Font = new Font("Segoe UI", 11.25F);
            dataGridViewCellStyle3.ForeColor = Color.Black;
            dataGridViewCellStyle3.SelectionBackColor = Color.FromArgb(231, 229, 255);
            dataGridViewCellStyle3.SelectionForeColor = Color.FromArgb(71, 69, 94);
            dataGridViewCellStyle3.WrapMode = DataGridViewTriState.False;
            guna2DataGridView1.DefaultCellStyle = dataGridViewCellStyle3;
            guna2DataGridView1.EditMode = DataGridViewEditMode.EditProgrammatically;
            guna2DataGridView1.GridColor = Color.FromArgb(231, 229, 255);
            guna2DataGridView1.Location = new Point(17, 68);
            guna2DataGridView1.Margin = new Padding(3, 4, 3, 4);
            guna2DataGridView1.Name = "guna2DataGridView1";
            guna2DataGridView1.RowHeadersVisible = false;
            guna2DataGridView1.Size = new Size(1207, 356);
            guna2DataGridView1.TabIndex = 0;
            guna2DataGridView1.ThemeStyle.AlternatingRowsStyle.BackColor = Color.White;
            guna2DataGridView1.ThemeStyle.AlternatingRowsStyle.Font = null;
            guna2DataGridView1.ThemeStyle.AlternatingRowsStyle.ForeColor = Color.Empty;
            guna2DataGridView1.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = Color.Empty;
            guna2DataGridView1.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = Color.Empty;
            guna2DataGridView1.ThemeStyle.BackColor = Color.White;
            guna2DataGridView1.ThemeStyle.GridColor = Color.FromArgb(231, 229, 255);
            guna2DataGridView1.ThemeStyle.HeaderStyle.BackColor = Color.FromArgb(100, 88, 255);
            guna2DataGridView1.ThemeStyle.HeaderStyle.BorderStyle = DataGridViewHeaderBorderStyle.None;
            guna2DataGridView1.ThemeStyle.HeaderStyle.Font = new Font("Segoe UI", 11.25F);
            guna2DataGridView1.ThemeStyle.HeaderStyle.ForeColor = Color.White;
            guna2DataGridView1.ThemeStyle.HeaderStyle.HeaightSizeMode = DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            guna2DataGridView1.ThemeStyle.HeaderStyle.Height = 4;
            guna2DataGridView1.ThemeStyle.ReadOnly = false;
            guna2DataGridView1.ThemeStyle.RowsStyle.BackColor = Color.White;
            guna2DataGridView1.ThemeStyle.RowsStyle.BorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            guna2DataGridView1.ThemeStyle.RowsStyle.Font = new Font("Segoe UI", 11.25F);
            guna2DataGridView1.ThemeStyle.RowsStyle.ForeColor = Color.Black;
            guna2DataGridView1.ThemeStyle.RowsStyle.Height = 25;
            guna2DataGridView1.ThemeStyle.RowsStyle.SelectionBackColor = Color.FromArgb(231, 229, 255);
            guna2DataGridView1.ThemeStyle.RowsStyle.SelectionForeColor = Color.FromArgb(71, 69, 94);
            guna2DataGridView1.CellClick += guna2DataGridView1_CellClick;
            // 
            // label1
            // 
            label1.Font = new Font("Century Gothic", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Image = (Image)resources.GetObject("label1.Image");
            label1.ImageAlign = ContentAlignment.MiddleLeft;
            label1.Location = new Point(37, 7);
            label1.Name = "label1";
            label1.Size = new Size(249, 57);
            label1.TabIndex = 1;
            label1.Text = "Phone Stock";
            label1.TextAlign = ContentAlignment.MiddleRight;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.ForeColor = Color.Black;
            label2.Location = new Point(152, 521);
            label2.Name = "label2";
            label2.Size = new Size(72, 20);
            label2.TabIndex = 2;
            label2.Text = "Company";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.ForeColor = Color.Black;
            label3.Location = new Point(152, 580);
            label3.Name = "label3";
            label3.Size = new Size(96, 20);
            label3.TabIndex = 3;
            label3.Text = "Model Name";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.ForeColor = Color.Black;
            label4.Location = new Point(152, 640);
            label4.Name = "label4";
            label4.Size = new Size(39, 20);
            label4.TabIndex = 4;
            label4.Text = "Ram";
            label4.Click += label4_Click;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.ForeColor = Color.Black;
            label5.Location = new Point(152, 699);
            label5.Name = "label5";
            label5.Size = new Size(115, 20);
            label5.TabIndex = 5;
            label5.Text = "Internal Storage";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.ForeColor = Color.Black;
            label6.Location = new Point(152, 752);
            label6.Name = "label6";
            label6.Size = new Size(141, 20);
            label6.TabIndex = 6;
            label6.Text = "Expandable storage";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.ForeColor = Color.Black;
            label7.Location = new Point(152, 817);
            label7.Name = "label7";
            label7.Size = new Size(58, 20);
            label7.TabIndex = 7;
            label7.Text = "Display";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.ForeColor = Color.Black;
            label8.Location = new Point(673, 817);
            label8.Name = "label8";
            label8.Size = new Size(41, 20);
            label8.TabIndex = 13;
            label8.Text = "Price";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.ForeColor = Color.Black;
            label9.Location = new Point(673, 752);
            label9.Name = "label9";
            label9.Size = new Size(100, 20);
            label9.TabIndex = 12;
            label9.Text = "Network Type";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.ForeColor = Color.Black;
            label10.Location = new Point(673, 699);
            label10.Name = "label10";
            label10.Size = new Size(69, 20);
            label10.TabIndex = 11;
            label10.Text = "Sim Type";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.ForeColor = Color.Black;
            label11.Location = new Point(673, 640);
            label11.Name = "label11";
            label11.Size = new Size(129, 20);
            label11.TabIndex = 10;
            label11.Text = "Fingerprint Sensor";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.ForeColor = Color.Black;
            label12.Location = new Point(673, 580);
            label12.Name = "label12";
            label12.Size = new Size(102, 20);
            label12.TabIndex = 9;
            label12.Text = "Front Camera ";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.ForeColor = Color.Black;
            label13.Location = new Point(673, 521);
            label13.Name = "label13";
            label13.Size = new Size(94, 20);
            label13.TabIndex = 8;
            label13.Text = "Rear Camera";
            // 
            // displaylabel
            // 
            displaylabel.AutoSize = true;
            displaylabel.Font = new Font("Segoe UI", 11.25F);
            displaylabel.ForeColor = Color.FromArgb(0, 118, 221);
            displaylabel.Location = new Point(299, 817);
            displaylabel.Name = "displaylabel";
            displaylabel.Size = new Size(45, 20);
            displaylabel.TabIndex = 19;
            displaylabel.Text = "------";
            // 
            // expandablelabel
            // 
            expandablelabel.AutoSize = true;
            expandablelabel.Font = new Font("Segoe UI", 11.25F);
            expandablelabel.ForeColor = Color.FromArgb(0, 118, 221);
            expandablelabel.Location = new Point(299, 752);
            expandablelabel.Name = "expandablelabel";
            expandablelabel.Size = new Size(45, 20);
            expandablelabel.TabIndex = 18;
            expandablelabel.Text = "------";
            // 
            // internallabel
            // 
            internallabel.AutoSize = true;
            internallabel.Font = new Font("Segoe UI", 11.25F);
            internallabel.ForeColor = Color.FromArgb(0, 118, 221);
            internallabel.Location = new Point(299, 699);
            internallabel.Name = "internallabel";
            internallabel.Size = new Size(45, 20);
            internallabel.TabIndex = 17;
            internallabel.Text = "------";
            // 
            // ramlabel
            // 
            ramlabel.AutoSize = true;
            ramlabel.Font = new Font("Segoe UI", 11.25F);
            ramlabel.ForeColor = Color.FromArgb(0, 118, 221);
            ramlabel.Location = new Point(299, 640);
            ramlabel.Name = "ramlabel";
            ramlabel.Size = new Size(45, 20);
            ramlabel.TabIndex = 16;
            ramlabel.Text = "------";
            // 
            // modellabel
            // 
            modellabel.AutoSize = true;
            modellabel.Font = new Font("Segoe UI", 11.25F);
            modellabel.ForeColor = Color.FromArgb(0, 118, 221);
            modellabel.Location = new Point(299, 580);
            modellabel.Name = "modellabel";
            modellabel.Size = new Size(45, 20);
            modellabel.TabIndex = 15;
            modellabel.Text = "------";
            modellabel.Click += label18_Click;
            // 
            // companylabel
            // 
            companylabel.AutoSize = true;
            companylabel.Font = new Font("Segoe UI", 11.25F);
            companylabel.ForeColor = Color.FromArgb(0, 118, 221);
            companylabel.Location = new Point(299, 521);
            companylabel.Name = "companylabel";
            companylabel.Size = new Size(45, 20);
            companylabel.TabIndex = 14;
            companylabel.Text = "------";
            // 
            // pricelabel
            // 
            pricelabel.AutoSize = true;
            pricelabel.Font = new Font("Segoe UI", 11.25F);
            pricelabel.ForeColor = Color.FromArgb(0, 118, 221);
            pricelabel.Location = new Point(822, 817);
            pricelabel.Name = "pricelabel";
            pricelabel.Size = new Size(45, 20);
            pricelabel.TabIndex = 25;
            pricelabel.Text = "------";
            // 
            // networklabel
            // 
            networklabel.AutoSize = true;
            networklabel.Font = new Font("Segoe UI", 11.25F);
            networklabel.ForeColor = Color.FromArgb(0, 118, 221);
            networklabel.Location = new Point(822, 752);
            networklabel.Name = "networklabel";
            networklabel.Size = new Size(45, 20);
            networklabel.TabIndex = 24;
            networklabel.Text = "------";
            // 
            // simlabel
            // 
            simlabel.AutoSize = true;
            simlabel.Font = new Font("Segoe UI", 11.25F);
            simlabel.ForeColor = Color.FromArgb(0, 118, 221);
            simlabel.Location = new Point(822, 699);
            simlabel.Name = "simlabel";
            simlabel.Size = new Size(45, 20);
            simlabel.TabIndex = 23;
            simlabel.Text = "------";
            // 
            // fingerlabel
            // 
            fingerlabel.AutoSize = true;
            fingerlabel.Font = new Font("Segoe UI", 11.25F);
            fingerlabel.ForeColor = Color.FromArgb(0, 118, 221);
            fingerlabel.Location = new Point(822, 640);
            fingerlabel.Name = "fingerlabel";
            fingerlabel.Size = new Size(45, 20);
            fingerlabel.TabIndex = 22;
            fingerlabel.Text = "------";
            // 
            // frontlabel
            // 
            frontlabel.AutoSize = true;
            frontlabel.Font = new Font("Segoe UI", 11.25F);
            frontlabel.ForeColor = Color.FromArgb(0, 118, 221);
            frontlabel.Location = new Point(822, 580);
            frontlabel.Name = "frontlabel";
            frontlabel.Size = new Size(45, 20);
            frontlabel.TabIndex = 21;
            frontlabel.Text = "------";
            // 
            // rearlabel
            // 
            rearlabel.AutoSize = true;
            rearlabel.Font = new Font("Segoe UI", 11.25F);
            rearlabel.ForeColor = Color.FromArgb(0, 118, 221);
            rearlabel.Location = new Point(822, 521);
            rearlabel.Name = "rearlabel";
            rearlabel.Size = new Size(45, 20);
            rearlabel.TabIndex = 20;
            rearlabel.Text = "------";
            // 
            // guna2Elipse3
            // 
            guna2Elipse3.BorderRadius = 26;
            guna2Elipse3.TargetControl = this;
            // 
            // UC_Stock
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            AutoSize = true;
            BackColor = Color.White;
            Controls.Add(pricelabel);
            Controls.Add(networklabel);
            Controls.Add(simlabel);
            Controls.Add(fingerlabel);
            Controls.Add(frontlabel);
            Controls.Add(rearlabel);
            Controls.Add(displaylabel);
            Controls.Add(expandablelabel);
            Controls.Add(internallabel);
            Controls.Add(ramlabel);
            Controls.Add(modellabel);
            Controls.Add(companylabel);
            Controls.Add(label8);
            Controls.Add(label9);
            Controls.Add(label10);
            Controls.Add(label11);
            Controls.Add(label12);
            Controls.Add(label13);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(guna2DataGridView1);
            Font = new Font("Segoe UI", 11.25F);
            ForeColor = Color.Black;
            Margin = new Padding(3, 4, 3, 4);
            Name = "UC_Stock";
            Size = new Size(1240, 1068);
            Enter += UC_Stock_Enter;
            ((System.ComponentModel.ISupportInitialize)guna2DataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Guna.UI2.WinForms.Guna2DataGridView guna2DataGridView1;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label label8;
        private Label label9;
        private Label label10;
        private Label label11;
        private Label label12;
        private Label label13;
        private Label displaylabel;
        private Label expandablelabel;
        private Label internallabel;
        private Label ramlabel;
        private Label modellabel;
        private Label companylabel;
        private Label pricelabel;
        private Label networklabel;
        private Label simlabel;
        private Label fingerlabel;
        private Label frontlabel;
        private Label rearlabel;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse3;
    }
}
