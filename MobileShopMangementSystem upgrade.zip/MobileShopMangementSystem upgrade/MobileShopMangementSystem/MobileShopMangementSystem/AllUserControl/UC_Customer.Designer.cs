﻿namespace MobileShopMangementSystem.AllUserControl
{
    partial class UC_Customer
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UC_Customer));
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges9 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges10 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges11 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges12 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges13 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges14 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges15 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges16 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges17 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges18 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            label1 = new Label();
            label2 = new Label();
            txtName = new Guna.UI2.WinForms.Guna2TextBox();
            label3 = new Label();
            txtContact = new Guna.UI2.WinForms.Guna2TextBox();
            label4 = new Label();
            txtEmail = new Guna.UI2.WinForms.Guna2TextBox();
            label5 = new Label();
            txtAddress = new Guna.UI2.WinForms.Guna2TextBox();
            label6 = new Label();
            txtGender = new Guna.UI2.WinForms.Guna2ComboBox();
            label8 = new Label();
            txtCompany = new Guna.UI2.WinForms.Guna2ComboBox();
            label7 = new Label();
            txtModel = new Guna.UI2.WinForms.Guna2ComboBox();
            label9 = new Label();
            label10 = new Label();
            label11 = new Label();
            label12 = new Label();
            label13 = new Label();
            label14 = new Label();
            label15 = new Label();
            label16 = new Label();
            internallabel = new Label();
            expandablelabel = new Label();
            rearlabel = new Label();
            frontlabel = new Label();
            fingerprintlabel = new Label();
            pricelabel = new Label();
            ramlabel = new Label();
            txtImei = new Guna.UI2.WinForms.Guna2TextBox();
            lebel24 = new Label();
            btnPurchase = new Guna.UI2.WinForms.Guna2Button();
            guna2Elipse1 = new Guna.UI2.WinForms.Guna2Elipse(components);
            SuspendLayout();
            // 
            // label1
            // 
            label1.Font = new Font("Century Gothic", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Image = (Image)resources.GetObject("label1.Image");
            label1.ImageAlign = ContentAlignment.MiddleLeft;
            label1.Location = new Point(31, 24);
            label1.Name = "label1";
            label1.Size = new Size(291, 43);
            label1.TabIndex = 0;
            label1.Text = "Customer Purchase";
            label1.TextAlign = ContentAlignment.MiddleRight;
            label1.Click += label1_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Century Gothic", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.Location = new Point(79, 97);
            label2.Name = "label2";
            label2.Size = new Size(53, 20);
            label2.TabIndex = 1;
            label2.Text = "Name";
            // 
            // txtName
            // 
            txtName.CustomizableEdges = customizableEdges1;
            txtName.DefaultText = "";
            txtName.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtName.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtName.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtName.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtName.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtName.Font = new Font("Segoe UI", 9F);
            txtName.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtName.Location = new Point(79, 120);
            txtName.Name = "txtName";
            txtName.PasswordChar = '\0';
            txtName.PlaceholderText = "";
            txtName.SelectedText = "";
            txtName.ShadowDecoration.CustomizableEdges = customizableEdges2;
            txtName.Size = new Size(384, 44);
            txtName.Style = Guna.UI2.WinForms.Enums.TextBoxStyle.Material;
            txtName.TabIndex = 2;
            txtName.TextChanged += guna2TextBox1_TextChanged;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Century Gothic", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.Location = new Point(79, 184);
            label3.Name = "label3";
            label3.Size = new Size(66, 20);
            label3.TabIndex = 3;
            label3.Text = "Gender";
            // 
            // txtContact
            // 
            txtContact.CustomizableEdges = customizableEdges3;
            txtContact.DefaultText = "";
            txtContact.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtContact.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtContact.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtContact.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtContact.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtContact.Font = new Font("Segoe UI", 9F);
            txtContact.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtContact.Location = new Point(79, 302);
            txtContact.Name = "txtContact";
            txtContact.PasswordChar = '\0';
            txtContact.PlaceholderText = "";
            txtContact.SelectedText = "";
            txtContact.ShadowDecoration.CustomizableEdges = customizableEdges4;
            txtContact.Size = new Size(384, 56);
            txtContact.Style = Guna.UI2.WinForms.Enums.TextBoxStyle.Material;
            txtContact.TabIndex = 6;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Century Gothic", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label4.Location = new Point(79, 279);
            label4.Name = "label4";
            label4.Size = new Size(132, 20);
            label4.TabIndex = 5;
            label4.Text = "Contact Number";
            // 
            // txtEmail
            // 
            txtEmail.CustomizableEdges = customizableEdges5;
            txtEmail.DefaultText = "";
            txtEmail.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtEmail.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtEmail.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtEmail.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtEmail.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtEmail.Font = new Font("Segoe UI", 9F);
            txtEmail.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtEmail.Location = new Point(79, 410);
            txtEmail.Name = "txtEmail";
            txtEmail.PasswordChar = '\0';
            txtEmail.PlaceholderText = "";
            txtEmail.SelectedText = "";
            txtEmail.ShadowDecoration.CustomizableEdges = customizableEdges6;
            txtEmail.Size = new Size(384, 40);
            txtEmail.Style = Guna.UI2.WinForms.Enums.TextBoxStyle.Material;
            txtEmail.TabIndex = 8;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Century Gothic", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label5.Location = new Point(79, 387);
            label5.Name = "label5";
            label5.Size = new Size(0, 20);
            label5.TabIndex = 7;
            // 
            // txtAddress
            // 
            txtAddress.CustomizableEdges = customizableEdges7;
            txtAddress.DefaultText = "";
            txtAddress.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtAddress.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtAddress.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtAddress.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtAddress.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtAddress.Font = new Font("Segoe UI", 9F);
            txtAddress.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtAddress.Location = new Point(79, 524);
            txtAddress.Name = "txtAddress";
            txtAddress.PasswordChar = '\0';
            txtAddress.PlaceholderText = "";
            txtAddress.SelectedText = "";
            txtAddress.ShadowDecoration.CustomizableEdges = customizableEdges8;
            txtAddress.Size = new Size(384, 50);
            txtAddress.Style = Guna.UI2.WinForms.Enums.TextBoxStyle.Material;
            txtAddress.TabIndex = 10;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Century Gothic", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label6.Location = new Point(79, 501);
            label6.Name = "label6";
            label6.Size = new Size(67, 20);
            label6.TabIndex = 9;
            label6.Text = "Address";
            // 
            // txtGender
            // 
            txtGender.BackColor = Color.Transparent;
            txtGender.CustomizableEdges = customizableEdges9;
            txtGender.DrawMode = DrawMode.OwnerDrawFixed;
            txtGender.DropDownStyle = ComboBoxStyle.DropDownList;
            txtGender.FocusedColor = Color.FromArgb(94, 148, 255);
            txtGender.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtGender.Font = new Font("Segoe UI", 10F);
            txtGender.ForeColor = Color.FromArgb(68, 88, 112);
            txtGender.ItemHeight = 30;
            txtGender.Items.AddRange(new object[] { "Male", "Female" });
            txtGender.Location = new Point(79, 207);
            txtGender.Name = "txtGender";
            txtGender.ShadowDecoration.CustomizableEdges = customizableEdges10;
            txtGender.Size = new Size(384, 36);
            txtGender.Style = Guna.UI2.WinForms.Enums.TextBoxStyle.Material;
            txtGender.TabIndex = 13;
            txtGender.SelectedIndexChanged += txtGender_SelectedIndexChanged;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Century Gothic", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label8.Location = new Point(79, 387);
            label8.Name = "label8";
            label8.Size = new Size(66, 20);
            label8.TabIndex = 14;
            label8.Text = "Email ID";
            // 
            // txtCompany
            // 
            txtCompany.BackColor = Color.Transparent;
            txtCompany.CustomizableEdges = customizableEdges11;
            txtCompany.DrawMode = DrawMode.OwnerDrawFixed;
            txtCompany.DropDownStyle = ComboBoxStyle.DropDownList;
            txtCompany.FocusedColor = Color.FromArgb(94, 148, 255);
            txtCompany.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtCompany.Font = new Font("Segoe UI", 10F);
            txtCompany.ForeColor = Color.FromArgb(68, 88, 112);
            txtCompany.ItemHeight = 30;
            txtCompany.Location = new Point(566, 120);
            txtCompany.Name = "txtCompany";
            txtCompany.ShadowDecoration.CustomizableEdges = customizableEdges12;
            txtCompany.Size = new Size(331, 36);
            txtCompany.Style = Guna.UI2.WinForms.Enums.TextBoxStyle.Material;
            txtCompany.TabIndex = 16;
            txtCompany.SelectedIndexChanged += txtCompany_SelectedIndexChanged;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Century Gothic", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label7.Location = new Point(566, 97);
            label7.Name = "label7";
            label7.Size = new Size(81, 20);
            label7.TabIndex = 15;
            label7.Text = "Company";
            // 
            // txtModel
            // 
            txtModel.BackColor = Color.Transparent;
            txtModel.CustomizableEdges = customizableEdges13;
            txtModel.DrawMode = DrawMode.OwnerDrawFixed;
            txtModel.DropDownStyle = ComboBoxStyle.DropDownList;
            txtModel.FocusedColor = Color.FromArgb(94, 148, 255);
            txtModel.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtModel.Font = new Font("Segoe UI", 10F);
            txtModel.ForeColor = Color.FromArgb(68, 88, 112);
            txtModel.ItemHeight = 30;
            txtModel.Location = new Point(566, 207);
            txtModel.Name = "txtModel";
            txtModel.ShadowDecoration.CustomizableEdges = customizableEdges14;
            txtModel.Size = new Size(331, 36);
            txtModel.Style = Guna.UI2.WinForms.Enums.TextBoxStyle.Material;
            txtModel.TabIndex = 18;
            txtModel.SelectedIndexChanged += txtModel_SelectedIndexChanged;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Century Gothic", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label9.Location = new Point(566, 184);
            label9.Name = "label9";
            label9.Size = new Size(57, 20);
            label9.TabIndex = 17;
            label9.Text = "Model";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Century Gothic", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label10.Location = new Point(566, 321);
            label10.Name = "label10";
            label10.Size = new Size(41, 20);
            label10.TabIndex = 19;
            label10.Text = "Ram";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Century Gothic", 9F);
            label11.Location = new Point(566, 341);
            label11.Name = "label11";
            label11.Size = new Size(104, 17);
            label11.TabIndex = 20;
            label11.Text = "Internal Stroage";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Century Gothic", 9F);
            label12.Location = new Point(566, 358);
            label12.Name = "label12";
            label12.Size = new Size(129, 17);
            label12.TabIndex = 21;
            label12.Text = "Expandable Storage";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Century Gothic", 9F);
            label13.Location = new Point(566, 375);
            label13.Name = "label13";
            label13.Size = new Size(86, 17);
            label13.TabIndex = 22;
            label13.Text = "Rear Camera";
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Font = new Font("Century Gothic", 9F);
            label14.Location = new Point(566, 392);
            label14.Name = "label14";
            label14.Size = new Size(89, 17);
            label14.TabIndex = 23;
            label14.Text = "Front Camera";
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Font = new Font("Century Gothic", 9F);
            label15.Location = new Point(566, 409);
            label15.Name = "label15";
            label15.Size = new Size(113, 17);
            label15.TabIndex = 24;
            label15.Text = "Fingerprint Sensor";
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Font = new Font("Century Gothic", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label16.Location = new Point(762, 425);
            label16.Name = "label16";
            label16.Size = new Size(47, 21);
            label16.TabIndex = 25;
            label16.Text = "Price";
            label16.Click += label16_Click;
            // 
            // internallabel
            // 
            internallabel.AutoSize = true;
            internallabel.Font = new Font("Century Gothic", 9F);
            internallabel.Location = new Point(695, 341);
            internallabel.Name = "internallabel";
            internallabel.Size = new Size(28, 17);
            internallabel.TabIndex = 26;
            internallabel.Text = "-----";
            // 
            // expandablelabel
            // 
            expandablelabel.AutoSize = true;
            expandablelabel.Font = new Font("Century Gothic", 9F);
            expandablelabel.Location = new Point(695, 358);
            expandablelabel.Name = "expandablelabel";
            expandablelabel.Size = new Size(28, 17);
            expandablelabel.TabIndex = 27;
            expandablelabel.Text = "-----";
            // 
            // rearlabel
            // 
            rearlabel.AutoSize = true;
            rearlabel.Font = new Font("Century Gothic", 9F);
            rearlabel.Location = new Point(695, 375);
            rearlabel.Name = "rearlabel";
            rearlabel.Size = new Size(28, 17);
            rearlabel.TabIndex = 28;
            rearlabel.Text = "-----";
            // 
            // frontlabel
            // 
            frontlabel.AutoSize = true;
            frontlabel.Font = new Font("Century Gothic", 9F);
            frontlabel.Location = new Point(695, 392);
            frontlabel.Name = "frontlabel";
            frontlabel.Size = new Size(28, 17);
            frontlabel.TabIndex = 29;
            frontlabel.Text = "-----";
            // 
            // fingerprintlabel
            // 
            fingerprintlabel.AutoSize = true;
            fingerprintlabel.Font = new Font("Century Gothic", 9F);
            fingerprintlabel.Location = new Point(695, 410);
            fingerprintlabel.Name = "fingerprintlabel";
            fingerprintlabel.Size = new Size(28, 17);
            fingerprintlabel.TabIndex = 30;
            fingerprintlabel.Text = "-----";
            // 
            // pricelabel
            // 
            pricelabel.AutoSize = true;
            pricelabel.Font = new Font("Century Gothic", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            pricelabel.Location = new Point(815, 429);
            pricelabel.Name = "pricelabel";
            pricelabel.Size = new Size(35, 21);
            pricelabel.TabIndex = 31;
            pricelabel.Text = "-----";
            // 
            // ramlabel
            // 
            ramlabel.AutoSize = true;
            ramlabel.Font = new Font("Century Gothic", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            ramlabel.Location = new Point(612, 321);
            ramlabel.Name = "ramlabel";
            ramlabel.Size = new Size(55, 21);
            ramlabel.TabIndex = 32;
            ramlabel.Text = "---------";
            // 
            // txtImei
            // 
            txtImei.CustomizableEdges = customizableEdges15;
            txtImei.DefaultText = "";
            txtImei.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtImei.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtImei.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtImei.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtImei.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtImei.Font = new Font("Segoe UI", 9F);
            txtImei.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtImei.Location = new Point(556, 538);
            txtImei.Name = "txtImei";
            txtImei.PasswordChar = '\0';
            txtImei.PlaceholderText = "";
            txtImei.SelectedText = "";
            txtImei.ShadowDecoration.CustomizableEdges = customizableEdges16;
            txtImei.Size = new Size(331, 36);
            txtImei.Style = Guna.UI2.WinForms.Enums.TextBoxStyle.Material;
            txtImei.TabIndex = 33;
            // 
            // lebel24
            // 
            lebel24.AutoSize = true;
            lebel24.Font = new Font("Century Gothic", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lebel24.Location = new Point(556, 501);
            lebel24.Name = "lebel24";
            lebel24.Size = new Size(42, 20);
            lebel24.TabIndex = 34;
            lebel24.Text = "IMEI";
            lebel24.Click += label24_Click;
            // 
            // btnPurchase
            // 
            btnPurchase.BorderRadius = 25;
            btnPurchase.BorderThickness = 1;
            btnPurchase.CheckedState.FillColor = Color.White;
            btnPurchase.CustomizableEdges = customizableEdges17;
            btnPurchase.DisabledState.BorderColor = Color.DarkGray;
            btnPurchase.DisabledState.CustomBorderColor = Color.DarkGray;
            btnPurchase.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnPurchase.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnPurchase.FillColor = Color.FromArgb(0, 118, 221);
            btnPurchase.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnPurchase.ForeColor = Color.White;
            btnPurchase.Image = (Image)resources.GetObject("btnPurchase.Image");
            btnPurchase.ImageAlign = HorizontalAlignment.Left;
            btnPurchase.ImageSize = new Size(30, 30);
            btnPurchase.Location = new Point(642, 610);
            btnPurchase.Name = "btnPurchase";
            btnPurchase.ShadowDecoration.CustomizableEdges = customizableEdges18;
            btnPurchase.Size = new Size(198, 46);
            btnPurchase.TabIndex = 35;
            btnPurchase.Text = "Purchase this Item";
            btnPurchase.TextAlign = HorizontalAlignment.Left;
            btnPurchase.Click += btnPurchase_Click;
            // 
            // guna2Elipse1
            // 
            guna2Elipse1.BorderRadius = 26;
            guna2Elipse1.TargetControl = this;
            // 
            // UC_Customer
            // 
            AutoScaleDimensions = new SizeF(8F, 17F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            Controls.Add(btnPurchase);
            Controls.Add(lebel24);
            Controls.Add(txtImei);
            Controls.Add(ramlabel);
            Controls.Add(pricelabel);
            Controls.Add(fingerprintlabel);
            Controls.Add(frontlabel);
            Controls.Add(rearlabel);
            Controls.Add(expandablelabel);
            Controls.Add(internallabel);
            Controls.Add(label16);
            Controls.Add(label15);
            Controls.Add(label14);
            Controls.Add(label13);
            Controls.Add(label12);
            Controls.Add(label11);
            Controls.Add(label10);
            Controls.Add(txtModel);
            Controls.Add(label9);
            Controls.Add(txtCompany);
            Controls.Add(label7);
            Controls.Add(label8);
            Controls.Add(txtGender);
            Controls.Add(txtAddress);
            Controls.Add(label6);
            Controls.Add(txtEmail);
            Controls.Add(label5);
            Controls.Add(txtContact);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(txtName);
            Controls.Add(label2);
            Controls.Add(label1);
            Font = new Font("Century Gothic", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Name = "UC_Customer";
            Size = new Size(1317, 1029);
            Enter += UC_Customer_Enter;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Guna.UI2.WinForms.Guna2TextBox txtName;
        private Label label3;
        private Guna.UI2.WinForms.Guna2TextBox txtContact;
        private Label label4;
        private Guna.UI2.WinForms.Guna2TextBox txtEmail;
        private Label label5;
        private Guna.UI2.WinForms.Guna2TextBox txtAddress;
        private Label label6;
        private Guna.UI2.WinForms.Guna2ComboBox txtGender;
        private Label label8;
        private Guna.UI2.WinForms.Guna2ComboBox txtCompany;
        private Label label7;
        private Guna.UI2.WinForms.Guna2ComboBox txtModel;
        private Label label9;
        private Label label10;
        private Label label11;
        private Label label12;
        private Label label13;
        private Label label14;
        private Label label15;
        private Label label16;
        private Label internallabel;
        private Label expandablelabel;
        private Label rearlabel;
        private Label frontlabel;
        private Label fingerprintlabel;
        private Label pricelabel;
        private Label ramlabel;
        private Guna.UI2.WinForms.Guna2TextBox txtImei;
        private Label lebel24;
        private Guna.UI2.WinForms.Guna2Button btnPurchase;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse1;
    }
}
